export interface IAlgorithmResult {
  path: number[];
  time: number;
  iterations: number;
  length: number;
}
