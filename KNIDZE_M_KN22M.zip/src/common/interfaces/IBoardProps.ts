import ACity from './ACity';

export interface IBoardProps {
  propsCities: ACity[];
}
