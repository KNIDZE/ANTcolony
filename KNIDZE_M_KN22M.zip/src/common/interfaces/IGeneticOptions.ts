export interface IGeneticOptions {
  populationSize: number;
  generationAmount: number;
  mutationAmount: number;
}
