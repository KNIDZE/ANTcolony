export default interface ICoefficients {
  alpha: number;
  beta: number;
  Q: number;
  evaporation: number;
  antsAmount: number;
};

