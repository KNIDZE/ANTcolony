export default interface CityProps {
  x: number;
  y: number;
  id: number;
  position: number;
};
