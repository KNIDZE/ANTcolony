import React, { ReactElement } from 'react';
import './App.css';
import { ACP } from './pages/ant_colony_page/ACP';

function App(): ReactElement {
  return (
    <div className="App">
      <ACP />
    </div>
  );
}

export default App;
